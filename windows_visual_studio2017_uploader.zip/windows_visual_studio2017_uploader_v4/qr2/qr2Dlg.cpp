
// qr2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "qr2.h"
#include "qr2Dlg.h"
#include "afxdialogex.h"
#include "qrwindow.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include <thread>
// CAboutDlg dialog used for App About

#include <vector>
#include <string>
#include <windows.h>
#include "AfxWin.h"
#include "sha256.h"
#include <iostream>
#include <fstream>


std::vector < std::string > filenames;
char strbuff1[5000];

SDL_mutex *global_win_mutex;
bool global_win_open;
CButton *glob_m_clickupload_button = NULL;
CSpinButtonCtrl *glob_m_spin1 = NULL;
CSpinButtonCtrl *glob_m_spin2 = NULL;
CSpinButtonCtrl *glob_m_spin3 = NULL;
CSpinButtonCtrl *glob_m_spin4 = NULL;
CButton *glob_m_defaultb = NULL;

std::vector<std::string> utf8purefilenames_to_display;
extern std::string getpurefilename(std::string relativename);

int settings_fps_value = 17;
int settings_err_value = 50;
int settings_qrsize_value = 585;
int settings_inittime_value = 6;

const char *about = "By pawel.m.wrobel@gmail.com";

std::string utf8_encode(const std::wstring &wstr)
{
	if (wstr.empty()) return std::string();
	int size_needed = WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), NULL, 0, NULL, NULL);
	std::string strTo(size_needed, 0);
	WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), &strTo[0], size_needed, NULL, NULL);
	return strTo;
}


void fill_shortfilenames_and_names_to_display(CString strText) {
	int length = GetShortPathName(strText, NULL, 0);
	TCHAR* b = new TCHAR[length];
	filenames.clear();

	length = GetShortPathName(strText, b, length);
	//filenames.push_back(std::string(strbuff1));
	//std::string u8 =std::string(utf8_encode(std::wstring(strText)));
	std::string u8 = std::string(utf8_encode(std::wstring(strText)));
	filenames.push_back(u8);
	//AfxMessageBox(strText);
	// TODO:  Add your control notification handler code here'
	utf8purefilenames_to_display.clear();
	std::string u8disp = getpurefilename(std::string(utf8_encode(std::wstring(strText))));
	utf8purefilenames_to_display.push_back(u8disp);

	delete[]b;

}

int trim(int val, int min, int max) {
	int ret = val;
	if (val < min)
		ret = min;
	if (val > max)
		ret = max;
	return ret;
}

void Cqr2Dlg::disk_save_settings() {

	LPWSTR *szArgList;
	int argCount;

	szArgList = CommandLineToArgvW(GetCommandLine(), &argCount);
	if (szArgList == NULL)
	{
		TRACE("Args are null !\n");
	}

	wcstombs(strbuff1, szArgList[0], 5000);
	std::string binpath(strbuff1);

	int posslash = binpath.length() - 1;
	while (binpath.c_str()[binpath.length() - 1] != '\\' &&
		binpath.c_str()[binpath.length() - 1] != '\\\\') {
		binpath.resize(binpath.size() - 1);
	}

	std::string settingpath = binpath + std::string("data\\settings.txt");

	std::ofstream newFile(settingpath, std::ios_base::trunc);

	newFile << settings_fps_value << std::endl;
	newFile << settings_err_value << std::endl;
	newFile << settings_qrsize_value << std::endl;
	newFile << settings_inittime_value << std::endl;
	LocalFree(szArgList);
}

void Cqr2Dlg::read_disk_settings() {

	LPWSTR *szArgList;
	int argCount;

	szArgList = CommandLineToArgvW(GetCommandLine(), &argCount);
	if (szArgList == NULL)
	{
		TRACE("Args are null !\n");
	}

	wcstombs(strbuff1, szArgList[0], 5000);
	std::string binpath(strbuff1);

	int posslash = binpath.length() - 1;
	while (binpath.c_str()[binpath.length() - 1] != '\\' &&
		binpath.c_str()[binpath.length() - 1] != '\\\\') {
		binpath.resize(binpath.size() - 1);
	}

	std::string settingpath = binpath + std::string("data\\settings.txt");

	std::fstream myfile(settingpath, std::ios_base::in);

	int a;
	myfile >> a;
	if (a >= 5 && a <= 60)
		settings_fps_value = a;
	myfile >> a;
	if (a >= 20 && a <= 80)
		settings_err_value = a;
	myfile >> a;
	if (a >= 95 && a <= 1205)
		settings_qrsize_value = a;
	myfile >> a;
	if (a >= 3 && a <= 10)
		settings_inittime_value = a;

	LocalFree(szArgList);
};


void Cqr2Dlg::do_the_startup() {
	m_visible = true;
	LPWSTR *szArgList;
	int argCount;

	szArgList = CommandLineToArgvW(GetCommandLine(), &argCount);
	if (szArgList == NULL)
	{
		TRACE("Unable to parse command line\n");
		//MessageBox(NULL, L"Unable to parse command line", L"Error", MB_OK);
	}
	//TRACE("QQQQQQQQQQQ %d\n", argCount);
	if (argCount > 1) {
		
		fill_shortfilenames_and_names_to_display(szArgList[1]);

		SDL_LockMutex(global_win_mutex);
		//AfxMessageBox(_T("aaaaaaaaaaaaaaaaaaatttttt"));
		m_fileselector.SetWindowTextW(szArgList[1]);
		//m_fileselector.setLimitText(szArgList[1]);
		global_win_open = true;
		glob_m_clickupload_button->SetWindowTextW(_T("Upload file (in progress..)"));
		m_clickupload_button.EnableWindow(false);
		glob_m_spin1->EnableWindow(false);
		glob_m_spin2->EnableWindow(false);
		glob_m_spin3->EnableWindow(false);
		glob_m_spin4->EnableWindow(false);
		glob_m_defaultb->EnableWindow(false);
		SDL_UnlockMutex(global_win_mutex);

		std::thread([] {
			//std::this_thread::sleep_for(std::chrono::seconds(1));
			SDL_Delay(500);
			open_window(filenames, settings_fps_value, settings_err_value,
				settings_qrsize_value, settings_inittime_value);
			close_window(); }).detach();
		//this->ShowWindow(SW_HIDE);
		//this->UpdateWindow();
		m_visible = false;
	} 

	
	LocalFree(szArgList);
};



class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	CStatic m_about;
	CButton m_okabout;
	afx_msg void OnBnClickedOk();
	afx_msg void OnStnClickedStaticabout();
};




CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_about, m_about);
	DDX_Control(pDX, IDOK, m_okabout);

	SHA256 sha256streamB;
	sha256streamB.add(std::string(about).c_str(), strlen(std::string(about).c_str()));
	std::string hash = sha256streamB.getHash();
	std::string expected("f3cb8a91df9f285664cf45b3e7ebe64299d7c026ea0adc7ab3bfb3f1365e968f");
	if (hash != expected) {
		exit(0);
	}

	std::string t(about);
	CA2T wt(t.c_str());
	m_about.SetWindowTextW(wt);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CAboutDlg::OnBnClickedOk)
	ON_STN_CLICKED(IDC_STATIC_about, &CAboutDlg::OnStnClickedStaticabout)
END_MESSAGE_MAP()


// Cqr2Dlg dialog

void Cqr2Dlg::do_speed_estimation_to_textfield() {
	CString n;
	double speed = 0;
	speed = (1.0 - (double)settings_err_value / 100.0) *
		((double)settings_fps_value) * ((settings_qrsize_value - 4.0)/1024.0);
	n.Format(_T("%.2f KB/s"), speed);
	this->m_edittext_estuploadspeed.SetWindowTextW(n);
};

void Cqr2Dlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos)
{
	if (!m_visible)
		lpwndpos->flags &= ~SWP_SHOWWINDOW;

	CDialogEx::OnWindowPosChanging(lpwndpos);
}

Cqr2Dlg::Cqr2Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_QR2_DIALOG, pParent)
{
	global_win_mutex = SDL_CreateMutex();
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	SDL_LockMutex(global_win_mutex);
	global_win_open = false;
	
	SDL_UnlockMutex(global_win_mutex);
	
}

Cqr2Dlg::~Cqr2Dlg()
{
	SDL_LockMutex(global_win_mutex);
	glob_m_clickupload_button = NULL;
	SDL_UnlockMutex(global_win_mutex);
	SDL_DestroyMutex(global_win_mutex);
	disk_save_settings();
}

void Cqr2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MFCEDITBROWSE1, m_fileselector);

	DDX_Control(pDX, IDC_EDIT1, m_edit_fpsval);
	DDX_Control(pDX, IDC_EDIT2, m_edit_errval);
	DDX_Control(pDX, IDC_EDIT3, m_edit_qrsize);
	DDX_Control(pDX, IDC_EDIT4, m_edit_inittime);
	m_edit_fpsval.ModifyStyle(0, ES_NUMBER);
	m_edit_errval.ModifyStyle(0, ES_NUMBER);
	m_edit_qrsize.ModifyStyle(0, ES_NUMBER);
	m_edit_inittime.ModifyStyle(0, ES_NUMBER);
	m_edit_fpsval.EnableWindow(false);
	m_edit_errval.EnableWindow(false);
	m_edit_qrsize.EnableWindow(false);
	m_edit_inittime.EnableWindow(false);
	read_disk_settings();
	CString n;
	n.Format(_T("%d"), settings_fps_value);
	m_edit_fpsval.SetWindowTextW(n);
	n.Format(_T("%d"), settings_err_value);
	m_edit_errval.SetWindowTextW(n);
	n.Format(_T("%d"), settings_qrsize_value);
	m_edit_qrsize.SetWindowTextW(n);
	n.Format(_T("%d"), settings_inittime_value);
	m_edit_inittime.SetWindowTextW(n);
	DDX_Control(pDX, IDC_BUTTON1, m_clickupload_button);

	//glob_m_clickupload_button->EnableWindow(true);
	DDX_Control(pDX, IDC_EDIT5, m_edittext_estuploadspeed);
	do_speed_estimation_to_textfield();
	DDX_Control(pDX, IDC_SPIN1, m_spin1);
	DDX_Control(pDX, IDC_SPIN2, m_spin2);
	DDX_Control(pDX, IDC_SPIN3, m_spin3);
	DDX_Control(pDX, IDC_SPIN4, m_spin4);
	DDX_Control(pDX, IDC_BUTTON2, m_defaultb);
	glob_m_clickupload_button = &m_clickupload_button;
	glob_m_spin1 = &m_spin1;
	glob_m_spin2 = &m_spin2;
	glob_m_spin3 = &m_spin3;
	glob_m_spin4 = &m_spin4;
	glob_m_defaultb = &m_defaultb;
	m_clickupload_button.EnableWindow(true);
	glob_m_spin1->EnableWindow(true);
	glob_m_spin2->EnableWindow(true);
	glob_m_spin3->EnableWindow(true);
	glob_m_spin4->EnableWindow(true);
	glob_m_defaultb->EnableWindow(true);
	do_the_startup();
	
}

BEGIN_MESSAGE_MAP(Cqr2Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &Cqr2Dlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON1, &Cqr2Dlg::OnBnClickedButton1)
	ON_EN_CHANGE(IDC_MFCEDITBROWSE1, &Cqr2Dlg::OnEnChangeMfceditbrowse1)
	ON_EN_CHANGE(IDC_EDIT2, &Cqr2Dlg::OnEnChangeEdit2)
	ON_EN_CHANGE(IDC_EDIT1, &Cqr2Dlg::OnEnChangeEdit1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, &Cqr2Dlg::OnDeltaposSpin1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN2, &Cqr2Dlg::OnDeltaposSpin2)
	ON_EN_CHANGE(IDC_EDIT3, &Cqr2Dlg::OnEnChangeEdit3)
	ON_EN_CHANGE(IDC_EDIT4, &Cqr2Dlg::OnEnChangeEdit4)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN3, &Cqr2Dlg::OnDeltaposSpin3)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN4, &Cqr2Dlg::OnDeltaposSpin4)
	ON_BN_CLICKED(IDC_BUTTON2, &Cqr2Dlg::OnBnClickedButton2)
	ON_EN_CHANGE(IDC_EDIT5, &Cqr2Dlg::OnEnChangeEdit5)
END_MESSAGE_MAP()


// Cqr2Dlg message handlers

BOOL Cqr2Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void Cqr2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cqr2Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cqr2Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void Cqr2Dlg::OnBnClickedOk()
{
	
	//init_and_set_external_file_info("C:\main.txt",
	//	"",
	//	555,
	//	0.5,
	//	511);
	//destroy_current_encoder();
	//finish_libqrencoder();
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
}



void Cqr2Dlg::OnBnClickedButton1()
{
//	go2();
//	open_window("");

//	SDL_Delay(3000);
	if (filenames.size() == 0) {
		AfxMessageBox(_T("Please select the file first !"));
	}
	else {
		bool winopen = false;
		SDL_LockMutex(global_win_mutex);
		winopen = global_win_open;
		SDL_UnlockMutex(global_win_mutex);
		if (winopen)
			return;
	//	filenames.resize(0);
		//filenames.push_back("C:\\main.cpp");
		SDL_LockMutex(global_win_mutex);
		global_win_open = true;
		glob_m_clickupload_button->SetWindowTextW(_T("Upload file (in progress..)"));
		m_clickupload_button.EnableWindow(false);
		glob_m_spin1->EnableWindow(false);
		glob_m_spin2->EnableWindow(false);
		glob_m_spin3->EnableWindow(false);
		glob_m_spin4->EnableWindow(false);
		glob_m_defaultb->EnableWindow(false);
		SDL_UnlockMutex(global_win_mutex);
		std::thread([] { 
			open_window(filenames, settings_fps_value, settings_err_value,
				settings_qrsize_value, settings_inittime_value);
			close_window();
		}).detach();
	}
	// TODO: Add your control notification handler code here
}





void Cqr2Dlg::OnEnChangeMfceditbrowse1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	CString strText;
	m_fileselector.GetWindowText(strText);
	const TCHAR* x = (LPCTSTR)strText;
	fill_shortfilenames_and_names_to_display(strText);
}





void Cqr2Dlg::OnEnChangeEdit2()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void Cqr2Dlg::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void Cqr2Dlg::OnDeltaposSpin1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int delta = -pNMUpDown->iDelta;
	settings_fps_value += delta;
	settings_fps_value = trim(settings_fps_value, 5, 60);
	CString n;
	n.Format(_T("%d"), settings_fps_value);
	m_edit_fpsval.SetWindowTextW(n);
	do_speed_estimation_to_textfield();
	*pResult = 0;
}


void Cqr2Dlg::OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int delta = -pNMUpDown->iDelta;
	settings_err_value += 5*delta;
	settings_err_value = trim(settings_err_value, 20, 80);
	CString n;
	n.Format(_T("%d"), settings_err_value);
	m_edit_errval.SetWindowTextW(n);
	do_speed_estimation_to_textfield();
	*pResult = 0;
}


void Cqr2Dlg::OnEnChangeEdit3()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void Cqr2Dlg::OnEnChangeEdit4()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void Cqr2Dlg::OnDeltaposSpin3(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int delta = -pNMUpDown->iDelta;
	settings_qrsize_value += 5*delta;
	settings_qrsize_value = trim(settings_qrsize_value, 95, 1205);
	CString n;
	n.Format(_T("%d"), settings_qrsize_value);
	m_edit_qrsize.SetWindowTextW(n);
	do_speed_estimation_to_textfield();
	*pResult = 0;
}


void Cqr2Dlg::OnDeltaposSpin4(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	int delta = -pNMUpDown->iDelta;
	settings_inittime_value += delta;
	settings_inittime_value = trim(settings_inittime_value, 3, 10);
	CString n;
	n.Format(_T("%d"), settings_inittime_value);
	m_edit_inittime.SetWindowTextW(n);
	do_speed_estimation_to_textfield();
	*pResult = 0;
}


void Cqr2Dlg::OnBnClickedButton2()
{
	settings_fps_value = 17;
	settings_err_value = 50;
	settings_qrsize_value = 585;
	settings_inittime_value = 6;
	CString n;
	n.Format(_T("%d"), 17);
	m_edit_fpsval.SetWindowTextW(n);
	n.Format(_T("%d"), 50);
	m_edit_errval.SetWindowTextW(n);
	n.Format(_T("%d"), 585);
	m_edit_qrsize.SetWindowTextW(n);
	n.Format(_T("%d"), 6);
	m_edit_inittime.SetWindowTextW(n);
	do_speed_estimation_to_textfield();
}


void Cqr2Dlg::OnEnChangeEdit5()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CAboutDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
}


void CAboutDlg::OnStnClickedStaticabout()
{
	// TODO: Add your control notification handler code here
}
