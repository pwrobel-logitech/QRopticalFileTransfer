
// qr2Dlg.h : header file
//

#pragma once
#include "afxeditbrowsectrl.h"
//#include "SDL2-2.0.5\include\SDL.h"
#include "SDL2-2.0.5\include\SDL.h"
#include "afxwin.h"
#include "afxcmn.h"



// Cqr2Dlg dialog
class Cqr2Dlg : public CDialogEx
{
// Construction
public:
	Cqr2Dlg(CWnd* pParent = NULL);	// standard constructor
	~Cqr2Dlg();

	void do_speed_estimation_to_textfield();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_QR2_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
// Implementation
protected:
	
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	void read_disk_settings();
	void disk_save_settings();
	bool m_visible;
	void do_the_startup();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnEnChangeMfceditbrowse1();
	CMFCEditBrowseCtrl m_fileselector;
	afx_msg void OnEnChangeEdit2();
	CEdit m_edit_fpsval;
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnDeltaposSpin1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnEnChangeEdit4();
	CEdit m_edit_errval;
	CEdit m_edit_qrsize;
	CEdit m_edit_inittime;
	afx_msg void OnDeltaposSpin3(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin4(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButton2();
	CButton m_clickupload_button;
	afx_msg void OnEnChangeEdit5();
	CEdit m_edittext_estuploadspeed;
	CSpinButtonCtrl m_spin1;
	CSpinButtonCtrl m_spin2;
	CSpinButtonCtrl m_spin3;
	CSpinButtonCtrl m_spin4;
	CButton m_defaultb;
};
