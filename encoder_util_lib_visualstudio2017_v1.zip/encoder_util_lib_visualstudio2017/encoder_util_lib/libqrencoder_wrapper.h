


// init libqrencoder - prepare to use with data of given fixed size
extern "C" __declspec(dllexport)  void init_libqrencoder(int size);

// deallocate all the resources needed for the libqrencoder module
extern "C" __declspec(dllexport)  void finish_libqrencoder();

// wrapper function to generate grayscale QR image
extern "C" __declspec(dllexport)  void generate_qr_greyscale_bitmap_data(const unsigned char* input_data,
                                       int input_length,
                                       char** out_image_data,
                                       int *out_image_data_width,
                                       int margin);

/* General purpose RS codec, integer symbols */
extern "C" __declspec(dllexport) void encode_rs_int(void *rs, int *data, int *parity);
extern "C" __declspec(dllexport) int decode_rs_int(void *rs, int *data, int *eras_pos, int no_eras);
extern "C" __declspec(dllexport) void *init_rs_int(int symsize, int gfpoly, int fcr,
	int prim, int nroots, int pad);
extern "C" __declspec(dllexport) void free_rs_int(void *rs);