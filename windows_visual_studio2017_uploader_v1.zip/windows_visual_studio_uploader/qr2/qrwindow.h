#pragma once


#include <string>
#include <vector>


void open_window(std::vector<std::string> fileNames, int fps, int errval, int qrsize, int inttime);

void close_window();





//private 

int dothemain();