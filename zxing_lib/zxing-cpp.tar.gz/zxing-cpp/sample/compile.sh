g++ -O2 test.cpp BufferBitmapSource.cpp -o out -I../core/src ../build/libzxing.a
